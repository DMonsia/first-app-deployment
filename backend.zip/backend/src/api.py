from fastapi import FastAPI


app = FastAPI()


@app.get("/")
def welcome():
    return f"Welcome!\
        This is my first deployment using docker and heroku"
